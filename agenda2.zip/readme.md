

documentação(datatables):

https://datatables.net/examples/data_sources/server_side
<<<<<<< HEAD


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
=======
>>>>>>> 8aec39c39b07e9b8d93f8082b05eb32fd3c42269
